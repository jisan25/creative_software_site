(() => {
var exports = {};
exports.id = 365;
exports.ids = [365];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 4801:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'schedule-demo',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7929)), "D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\schedule-demo\\page.js"],
          
        }]
      },
        {
        
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8326)), "D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\schedule-demo\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/schedule-demo/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/schedule-demo/page",
        pathname: "/schedule-demo",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 7207:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 954, 23))

/***/ }),

/***/ 7929:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(5124);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./app/db/Corporate.js
var Corporate = __webpack_require__(4603);
;// CONCATENATED MODULE: ./app/components/demo/ProductForm.js



const ProductForm = ({ productData })=>{
    // const {slug} = productData;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                style: {
                    marginBottom: "5px"
                },
                children: "Book A Demo"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-medium-emphasis",
                style: {
                    marginTop: "0px"
                },
                children: "Please complete the form below to schedule your demo."
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-person-fill"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Name"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-buildings-fill"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Company Name"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-telephone-fill"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "number",
                        placeholder: "Phone Number"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-envelope-fill"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Email"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            class: "bi bi-ubuntu"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Your Designation"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            class: "bi bi-building-fill-gear"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Type of Company"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-caret-down-fill"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                        className: "form-select",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                selected: true,
                                disabled: true,
                                children: "Select Company Size"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "1-10",
                                children: "1-10"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "11-50",
                                children: "11-50"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "51-200",
                                children: "51-200"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "201-500",
                                children: "201-500"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "501-1000",
                                children: "501-1000"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "1000+",
                                children: "1000+"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "employee",
                                children: "Employee"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-caret-down-fill"
                        })
                    }),
                    productData ? productData.slug && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                        className: "form-select",
                        defaultValue: productData.slug,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                disabled: true,
                                children: "Select Product"
                            }),
                            Corporate/* ProductsData */.G.map((item)=>{
                                // const { slug, title } = item;
                                return /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: item.slug,
                                    children: item.title
                                }, item.id);
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                        className: "form-select",
                        defaultValue: "select-product",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "select-product",
                                disabled: true,
                                children: "Select Product"
                            }),
                            Corporate/* ProductsData */.G.map((item)=>{
                                // const { slug, title } = item;
                                return /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: item.slug,
                                    children: item.title
                                }, item.id);
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-caret-down-fill"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                        className: "form-select",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                selected: true,
                                disabled: true,
                                children: "Select Country"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "1",
                                children: "Country 1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "2",
                                children: "Country 2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "3",
                                children: "Country 3"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            class: "bi bi-bullseye"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Solution Yor're Looking For"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-caret-down-fill"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                        className: "form-select",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                selected: true,
                                disabled: true,
                                children: "How Do You Know Us?"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "google",
                                children: "Google"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "fb",
                                children: "FB"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "linkedin",
                                children: "LinkedIn"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "direct",
                                children: "Direct"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                htmlFor: "add-comments",
                className: "mb-2",
                children: "Additional Comments or Question"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-chat-fill"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                        className: "form-control",
                        placeholder: "optional",
                        id: "add-comments"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "form-check mt-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-check-input",
                        type: "checkbox"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        className: "form-check-label",
                        style: {
                            fontSize: "14px"
                        },
                        children: "I agree to receive other communications from creative software"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "for more information check",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/privacy",
                                style: {
                                    textDecoration: "underline",
                                    color: "#0d6efd"
                                },
                                children: "our privacy policy"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    display: "grid",
                    placeItems: "end"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "btn btn-block btn-success schedule_btn",
                    type: "button",
                    children: "BOOK A DEMO NOW"
                })
            })
        ]
    });
};
/* harmony default export */ const demo_ProductForm = (ProductForm);

;// CONCATENATED MODULE: ./app/schedule-demo/page.js


const ScheduleDemoPage = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "bg-light min-vh-100 d-flex flex-row align-items-center schedule_page pt-5",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-md-6 mb-5",
                        style: {
                            marginTop: "20px"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "card mb-4 mx-4",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "card-body p-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(demo_ProductForm, {})
                            })
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const page = (ScheduleDemoPage);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,891,759,603], () => (__webpack_exec__(4801)));
module.exports = __webpack_exports__;

})();