(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 4416:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Nunito_27bdd8', '__Nunito_Fallback_27bdd8'","fontStyle":"normal"},
	"className": "__className_27bdd8"
};


/***/ }),

/***/ 9142:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2114)), "D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\page.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8326)), "D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 7789:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3332))

/***/ }),

/***/ 3332:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./app/components/home/PopUpAd.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

const PopUpAd = ()=>{
    const [totalTime, setTotalTime] = (0,react_.useState)(1);
    const [popup, setPopUp] = (0,react_.useState)(false);
    const handlePopUp = ()=>{
        if (localStorage.getItem("showedTime")) {
            if (localStorage.getItem("showedTime") < 3) {
                return document.querySelector(".popup").style.display = "block";
            } else {
                setPopUp(false);
                return;
            }
        }
        document.querySelector(".popup").style.display = "block";
    };
    (0,react_.useEffect)(()=>{
        setPopUp(true);
        handlePopUp();
        if (localStorage.getItem("showedTime")) {
            let timeShow = localStorage.getItem("showedTime");
            setTotalTime(timeShow);
        } else {
            localStorage.setItem("showedTime", 1);
        }
    }, []);
    const removePopUp = ()=>{
        document.querySelector(".popup").style.display = "none";
        document.querySelector(".pop-up-transparent-bg").style.display = "none";
        setPopUp(false);
        let totalTime = parseInt(localStorage.getItem("showedTime"));
        localStorage.setItem("showedTime", totalTime += 1);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: totalTime < 3 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: popup && "pop-up-transparent-bg"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "popup",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: removePopUp,
                            className: "popup-btn",
                            id: "close",
                            children: "\xd7"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/img/promotion.png",
                            alt: "promotion",
                            style: {
                                height: "262px",
                                width: "692px"
                            }
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const home_PopUpAd = (PopUpAd);

;// CONCATENATED MODULE: ./app/components/home/About.js

const About = ()=>{
    return(// about section
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "about",
        className: "about",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container-fluid container-xl",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row gx-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-6 d-flex flex-column justify-content-center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "content",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: "Who We Are"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    children: "Expedita voluptas omnis cupiditate totam eveniet nobis sint iste. Dolores est repellat corrupti reprehenderit."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Quisquam vel ut sint cum eos hic dolores aperiam. Sed deserunt et. Inventore et et dolor consequatur itaque ut voluptate sed et. Magnam nam ipsum tenetur suscipit voluptatum nam et est corrupti."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center text-lg-start",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: "#",
                                        className: "btn-read-more d-inline-flex align-items-center justify-content-center align-self-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Read More"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-arrow-right"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-6 d-flex align-items-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/img/about.jpg",
                            className: "img-fluid",
                            alt: ""
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const home_About = (About);

;// CONCATENATED MODULE: ./app/components/home/Counts.js

const Counts = ()=>{
    return(// counts section
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "counts",
        className: "counts",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container-fluid container-xl",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row gy-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-3 col-md-6",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "count-box",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-emoji-smile"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "233"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Happy Clients"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-3 col-md-6",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "count-box",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-journal-richtext",
                                    style: {
                                        color: "#ee6c20"
                                    }
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "521"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Projects"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-3 col-md-6",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "count-box",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-headset",
                                    style: {
                                        color: "#ee6c20"
                                    }
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "1463"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Hours Of Support"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-3 col-md-6",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "count-box",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-people",
                                    style: {
                                        color: "#ee6c20"
                                    }
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "15"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Hard Workers"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const home_Counts = (Counts);

;// CONCATENATED MODULE: ./app/components/home/Values.js

const Values = ()=>{
    return(// values section
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "values",
        className: "values",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-fluid container-xl",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Our Values"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Odit est perspiciatis laborum et dicta"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-4",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "assets/img/values-1.png",
                                        className: "img-fluid",
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Ad cupiditate sed est odio"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Eum ad dolor et. Autem aut fugiat debitis voluptatem consequuntur sit. Et veritatis id."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-4 mt-4 mt-lg-0",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "assets/img/values-2.png",
                                        className: "img-fluid",
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Voluptatem voluptatum alias"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Repudiandae amet nihil natus in distinctio suscipit id. Doloremque ducimus ea sit non."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-4 mt-4 mt-lg-0",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "assets/img/values-3.png",
                                        className: "img-fluid",
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Fugit cupiditate alias nobis."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Quam rem vitae est autem molestias explicabo debitis sint. Vero aliquid quidem commodi."
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const home_Values = (Values);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./app/components/home/Hero.js



const Hero = ()=>{
    return(// ====== hero section ======
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "hero",
        className: "hero d-flex align-items-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container-fluid container-xl",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-lg-6 d-flex flex-column justify-content-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                children: "We offer modern solutions for growing your business"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "We are Ready  Team of talented people  for design & Develop websites, Software & Apps."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "text-center text-lg-start",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "#",
                                                className: "btn-get-started scrollto d-inline-flex align-items-center justify-content-center align-self-center mr-5",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "Explore The Platform"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-arrow-right"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                href: "/schedule-demo",
                                                className: "font-bold scrollto d-inline-flex align-items-center justify-content-center align-self-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "Request A Demo"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-arrow-right"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "footer-newsletter col-lg-9 mt-2",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                                action: "",
                                                method: "post",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "email",
                                                        name: "email"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "submit",
                                                        value: "Subscribe"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "mt-2 news-letter-benifits",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                class: "bi bi-check-lg"
                                                            }),
                                                            " Free plan available"
                                                        ]
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                class: "bi bi-check-lg"
                                                            }),
                                                            " Easy Setup"
                                                        ]
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                class: "bi bi-check-lg"
                                                            }),
                                                            " No credit card required"
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-6 hero-img",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/img/hero-img.png",
                            className: "img-fluid",
                            alt: ""
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const home_Hero = (Hero);

;// CONCATENATED MODULE: ./app/components/home/Features.js

const Features = ()=>{
    const toggleTab = (e, id)=>{
        const tab = document.getElementById(id);
        // get all tabls
        const allTabs = document.querySelectorAll(".tab-pane");
        // remove active class from other tabsl
        allTabs.forEach((item)=>{
            if (item.classList.contains("active")) {
                item.classList.remove("active");
            }
        });
        // get all tab buttons
        const tabButtons = document.querySelectorAll(".nav-link");
        // remove active class from other tab buttons
        tabButtons.forEach((item)=>{
            if (item.classList.contains("active")) {
                item.classList.remove("active");
            }
        });
        // apply active class to the selected tab
        if (tab) {
            tab.classList.add("active");
        }
        console.log(e.target.classList.add("active"));
    };
    return(// features section
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "features",
        className: "features",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-fluid container-xl",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Features"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Laboriosam et omnis fuga quis dolor direda fara"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/img/features.png",
                                className: "img-fluid",
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6 mt-5 mt-lg-0 d-flex",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row align-self-center gy-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-md-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "feature-box d-flex align-items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-check"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    children: "Eos aspernatur rem"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-md-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "feature-box d-flex align-items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-check"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    children: "Facilis neque ipsa"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-md-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "feature-box d-flex align-items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-check"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    children: "Volup amet voluptas"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-md-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "feature-box d-flex align-items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-check"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    children: "Rerum omnis sint"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-md-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "feature-box d-flex align-items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-check"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    children: "Alias possimus"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-md-6",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "feature-box d-flex align-items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-check"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                    children: "Repellendus mollitia"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row feture-tabs",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-lg-6",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: "Neque officiis dolore maiores et exercitationem quae est seda lidera pat claero"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "nav nav-pills mb-3",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "nav-link active",
                                                style: {
                                                    cursor: "pointer"
                                                },
                                                // data-bs-toggle="pill"
                                                // href=""
                                                onClick: (e)=>toggleTab(e, "tab1"),
                                                children: "Saepe fuga 1"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "nav-link",
                                                onClick: (e)=>toggleTab(e, "tab2"),
                                                style: {
                                                    cursor: "pointer"
                                                },
                                                children: "Voluptates"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "nav-link",
                                                onClick: (e)=>toggleTab(e, "tab3"),
                                                style: {
                                                    cursor: "pointer"
                                                },
                                                children: "Corrupti"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "tab-content",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "tab-pane fade show active",
                                            id: "tab1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Consequuntur inventore voluptates consequatur aut vel et. Eos doloribus expedita. Sapiente atque consequatur minima nihil quae aspernatur quo suscipit voluptatem."
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "d-flex align-items-center mb-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-check2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            children: "Repudiandae rerum velit modi et officia quasi facilis"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Laborum omnis voluptates voluptas qui sit aliquam blanditiis. Sapiente minima commodi dolorum non eveniet magni quaerat nemo et."
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "d-flex align-items-center mb-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-check2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            children: "Incidunt non veritatis illum ea ut nisi"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Non quod totam minus repellendus autem sint velit. Rerum debitis facere soluta tenetur. Iure molestiae assumenda sunt qui inventore eligendi voluptates nisi at. Dolorem quo tempora. Quia et perferendis."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "tab-pane fade show",
                                            id: "tab2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    style: {
                                                        fontSize: "1.5rem",
                                                        fontWeight: "500"
                                                    },
                                                    children: "Tab 2"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Consequuntur inventore voluptates consequatur aut vel et. Eos doloribus expedita. Sapiente atque consequatur minima nihil quae aspernatur quo suscipit voluptatem."
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "d-flex align-items-center mb-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-check2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            children: "Repudiandae rerum velit modi et officia quasi facilis"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Laborum omnis voluptates voluptas qui sit aliquam blanditiis. Sapiente minima commodi dolorum non eveniet magni quaerat nemo et."
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "d-flex align-items-center mb-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-check2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            children: "Incidunt non veritatis illum ea ut nisi"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Non quod totam minus repellendus autem sint velit. Rerum debitis facere soluta tenetur. Iure molestiae assumenda sunt qui inventore eligendi voluptates nisi at. Dolorem quo tempora. Quia et perferendis."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "tab-pane fade show",
                                            id: "tab3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    style: {
                                                        fontSize: "1.5rem",
                                                        fontWeight: "500"
                                                    },
                                                    children: "Tab 3"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Consequuntur inventore voluptates consequatur aut vel et. Eos doloribus expedita. Sapiente atque consequatur minima nihil quae aspernatur quo suscipit voluptatem."
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "d-flex align-items-center mb-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-check2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            children: "Repudiandae rerum velit modi et officia quasi facilis"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Laborum omnis voluptates voluptas qui sit aliquam blanditiis. Sapiente minima commodi dolorum non eveniet magni quaerat nemo et."
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "d-flex align-items-center mb-2",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-check2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                            children: "Incidunt non veritatis illum ea ut nisi"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Non quod totam minus repellendus autem sint velit. Rerum debitis facere soluta tenetur. Iure molestiae assumenda sunt qui inventore eligendi voluptates nisi at. Dolorem quo tempora. Quia et perferendis."
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/img/features-2.png",
                                className: "img-fluid",
                                alt: ""
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row feature-icons",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            children: "Ratione mollitia eos ab laudantium rerum beatae quo"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-xl-4 text-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/img/features-3.png",
                                        className: "img-fluid p-4",
                                        alt: ""
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-xl-8 d-flex content",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row align-self-center gy-4",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-md-6 icon-box",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "ri-line-chart-line"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                children: "Corporis voluptates sit"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                children: "Consequuntur sunt aut quasi enim aliquam quae harum pariatur laboris nisi ut aliquip"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-md-6 icon-box",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "ri-stack-line"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                children: "Ullamco laboris nisi"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                children: "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-md-6 icon-box",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "ri-brush-4-line"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                children: "Labore consequatur"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                children: "Aut suscipit aut cum nemo deleniti aut omnis. Doloribus ut maiores omnis facere"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-md-6 icon-box",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "ri-magic-line"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                children: "Beatae veritatis"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                children: "Expedita veritatis consequuntur nihil tempore laudantium vitae denat pacta"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-md-6 icon-box",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "ri-command-line"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                children: "Molestiae dolor"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                children: "Et fuga et deserunt et enim. Dolorem architecto ratione tensa raptor marte"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-md-6 icon-box",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "ri-radar-line"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                children: "Explicabo consectetur"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                children: "Est autem dicta beatae suscipit. Sint veritatis et sit quasi ab aut inventore"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const home_Features = (Features);

// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\components\\home\\Services.js","import":"Nunito","arguments":[{"subsets":["cyrillic"]}],"variableName":"nunito"}
var target_path_app_components_home_Services_js_import_Nunito_arguments_subsets_cyrillic_variableName_nunito_ = __webpack_require__(4416);
var target_path_app_components_home_Services_js_import_Nunito_arguments_subsets_cyrillic_variableName_nunito_default = /*#__PURE__*/__webpack_require__.n(target_path_app_components_home_Services_js_import_Nunito_arguments_subsets_cyrillic_variableName_nunito_);
// EXTERNAL MODULE: ./app/db/Corporate.js
var Corporate = __webpack_require__(1762);
;// CONCATENATED MODULE: ./app/components/home/Services.js




const Services = ()=>{
    const [services, setServices] = (0,react_.useState)(Corporate/* default */.Z);
    const truncateParagraph = (paragraph, maxLength)=>{
        if (paragraph.length <= maxLength) {
            return paragraph;
        } else {
            return paragraph.slice(0, maxLength) + "...";
        }
    };
    return(// services section
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "services",
        className: "services",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-fluid container-xl",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Services"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Veritatis et dolores facere numquam et praesentium"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row gy-4",
                    children: services.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-4 col-md-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: `${"service-box"} ${item.color}`,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: `${item.icon} ${"icon"}`
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: (target_path_app_components_home_Services_js_import_Nunito_arguments_subsets_cyrillic_variableName_nunito_default()).className,
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: truncateParagraph(item.description, 300)
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: "#",
                                        className: "read-more",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Read More"
                                            }),
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-arrow-right"
                                            })
                                        ]
                                    })
                                ]
                            })
                        }, item.id))
                })
            ]
        })
    }));
};
/* harmony default export */ const home_Services = (Services);

;// CONCATENATED MODULE: ./app/components/home/Pricing.js

const Pricing = ()=>{
    return(// pricing section
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "pricing",
        className: "pricing",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-xl container-fluid",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Pricing"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Check our Pricing"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row gy-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-3 col-md-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        style: {
                                            color: "#07d5c0"
                                        },
                                        children: "Free Plan"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "price",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("sup", {
                                                children: "$"
                                            }),
                                            "0",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: " / mo"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/img/pricing-free.png",
                                        className: "img-fluid",
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Aida dere"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Nec feugiat nisl"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Nulla at volutpat dola"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "na",
                                                children: "Pharetra massa"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "na",
                                                children: "Massa ultricies mi"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        className: "btn-buy",
                                        children: "Buy Now"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-3 col-md-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "featured",
                                        children: "Featured"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        style: {
                                            color: "#65c600"
                                        },
                                        children: "Starter Plan"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "price",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("sup", {
                                                children: "$"
                                            }),
                                            "19",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: " / mo"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/img/pricing-starter.png",
                                        className: "img-fluid",
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Aida dere"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Nec feugiat nisl"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Nulla at volutpat dola"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Pharetra massa"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "na",
                                                children: "Massa ultricies mi"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        className: "btn-buy",
                                        children: "Buy Now"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-3 col-md-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        style: {
                                            color: "ff901c"
                                        },
                                        children: "Business Plan"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "price",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("sup", {
                                                children: "$"
                                            }),
                                            "29",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: " / mo"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/img/pricing-business.png",
                                        className: "img-fluid",
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Aida dere"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Nec feugiat nisl"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Nulla at volutpat dola"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Pharetra massa"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Massa ultricies mi"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        className: "btn-buy",
                                        children: "Buy Now"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-3 col-md-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        style: {
                                            color: "#ff0071"
                                        },
                                        children: "Ultimate Plan"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "price",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("sup", {
                                                children: "$"
                                            }),
                                            "49",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: " / mo"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/img/pricing-ultimate.png",
                                        className: "img-fluid",
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Aida dere"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Nec feugiat nisl"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Nulla at volutpat dola"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Pharetra massa"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Massa ultricies mi"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        className: "btn-buy",
                                        children: "Buy Now"
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const home_Pricing = (Pricing);

;// CONCATENATED MODULE: ./app/components/home/Faq.js
/* __next_internal_client_entry_do_not_use__ default auto */ 

const Faq = ()=>{
    const [show, setShow] = (0,react_.useState)(false);
    const toggleCollapse = (id)=>{
        const content = document.getElementById(id);
        if (content) {
            content.classList.toggle("collapse");
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "faq",
        className: "faq",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-xl container-fluid",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "F.A.Q"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Frequently Asked Questions"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "accordion accordion-flush",
                                id: "faqlist1",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "accordion-item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "accordion-header",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "accordion-button collapsed",
                                                    type: "button",
                                                    "data-bs-toggle": "collapse",
                                                    "data-bs-target": "#faq-content-1",
                                                    onClick: ()=>toggleCollapse("faq-content-1"),
                                                    children: "Non consectetur a erat nam at lectus urna duis?"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                id: "faq-content-1",
                                                className: `accordion-collapse collapse`,
                                                "data-bs-parent": "#faqlist1",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "accordion-body",
                                                    children: "Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non."
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "accordion-item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "accordion-header",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "accordion-button collapsed",
                                                    type: "button",
                                                    "data-bs-toggle": "collapse",
                                                    "data-bs-target": "#faq-content-2",
                                                    onClick: ()=>toggleCollapse("faq-content-2"),
                                                    children: "Feugiat scelerisque varius morbi enim nunc faucibus a pellentesque?"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                id: "faq-content-2",
                                                className: `accordion-collapse collapse`,
                                                "data-bs-parent": "#faqlist1",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "accordion-body",
                                                    children: "Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui."
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "accordion-item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "accordion-header",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "accordion-button collapsed",
                                                    type: "button",
                                                    "data-bs-toggle": "collapse",
                                                    "data-bs-target": "#faq-content-3",
                                                    onClick: ()=>toggleCollapse("faq-content-3"),
                                                    children: "Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi?"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                id: "faq-content-3",
                                                className: `accordion-collapse collapse`,
                                                "data-bs-parent": "#faqlist1",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "accordion-body",
                                                    children: "Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci. Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis convallis tellus. Urna molestie at elementum eu facilisis sed odio morbi quis"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "accordion accordion-flush",
                                id: "faqlist2",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "accordion-item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "accordion-header",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "accordion-button collapsed",
                                                    type: "button",
                                                    "data-bs-toggle": "collapse",
                                                    "data-bs-target": "#faq2-content-1",
                                                    onClick: ()=>toggleCollapse("faq2-content-1"),
                                                    children: "Ac odio tempor orci dapibus. Aliquam eleifend mi in nulla?"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                id: "faq2-content-1",
                                                className: `accordion-collapse collapse`,
                                                "data-bs-parent": "#faqlist2",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "accordion-body",
                                                    children: "Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim. Mauris ultrices eros in cursus turpis massa tincidunt dui."
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "accordion-item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "accordion-header",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "accordion-button collapsed",
                                                    type: "button",
                                                    "data-bs-toggle": "collapse",
                                                    "data-bs-target": "#faq2-content-2",
                                                    onClick: ()=>toggleCollapse("faq2-content-2"),
                                                    children: "Tempus quam pellentesque nec nam aliquam sem et tortor consequat?"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                id: "faq2-content-2",
                                                className: `accordion-collapse collapse`,
                                                "data-bs-parent": "#faqlist2",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "accordion-body",
                                                    children: "Molestie a iaculis at erat pellentesque adipiscing commodo. Dignissim suspendisse in est ante in. Nunc vel risus commodo viverra maecenas accumsan. Sit amet nisl suscipit adipiscing bibendum est. Purus gravida quis blandit turpis cursus in"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "accordion-item",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "accordion-header",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "accordion-button collapsed",
                                                    type: "button",
                                                    "data-bs-toggle": "collapse",
                                                    "data-bs-target": "#faq2-content-3",
                                                    onClick: ()=>toggleCollapse("faq2-content-3"),
                                                    children: "Varius vel pharetra vel turpis nunc eget lorem dolor?"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                id: "faq2-content-3",
                                                className: `accordion-collapse collapse`,
                                                "data-bs-parent": "#faqlist2",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "accordion-body",
                                                    children: "Laoreet sit amet cursus sit amet dictum sit amet justo. Mauris vitae ultricies leo integer malesuada nunc vel. Tincidunt eget nullam non nisi est sit amet. Turpis nunc eget lorem dolor sed. Ut venenatis tellus in metus vulputate eu scelerisque. Pellentesque diam volutpat commodo sed egestas egestas fringilla phasellus faucibus. Nibh tellus molestie nunc non blandit massa enim nec."
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const home_Faq = (Faq);

;// CONCATENATED MODULE: ./app/db/portfolio.js
const PortfolioData = [
    {
        id: 1,
        image: "/img/portfolio/portfolio-1.jpg",
        title: "App 1",
        category: "app",
        description: "App"
    },
    {
        id: 2,
        image: "/img/portfolio/portfolio-2.jpg",
        title: "Web 1",
        category: "web",
        description: "Web"
    },
    {
        id: 3,
        image: "/img/portfolio/portfolio-3.jpg",
        title: "card 1",
        category: "card",
        description: "card"
    },
    {
        id: 4,
        image: "/img/portfolio/portfolio-4.jpg",
        title: "Card 2",
        category: "card",
        description: "Card"
    },
    {
        id: 5,
        image: "/img/portfolio/portfolio-5.jpg",
        title: "App 2",
        category: "app",
        description: "App"
    },
    {
        id: 6,
        image: "/img/portfolio/portfolio-6.jpg",
        title: "Web 2",
        category: "web",
        description: "Web"
    },
    {
        id: 7,
        image: "/img/portfolio/portfolio-7.jpg",
        title: "App 3",
        category: "app",
        description: "App"
    },
    {
        id: 8,
        image: "/img/portfolio/portfolio-8.jpg",
        title: "Card 3",
        category: "card",
        description: "Card"
    },
    {
        id: 9,
        image: "/img/portfolio/portfolio-9.jpg",
        title: "Web 3",
        category: "web",
        description: "Web"
    }
];
/* harmony default export */ const portfolio = (PortfolioData);

;// CONCATENATED MODULE: ./app/components/home/Portfolio.js




const Portfolio = ()=>{
    const [portfolios, setPortfolios] = (0,react_.useState)(portfolio);
    const filterItem = (category)=>{
        const updatedPortfolios = portfolio.filter((item)=>{
            return item.category === category;
        });
        setPortfolios(updatedPortfolios);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "portfolio",
        className: "portfolio",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-fluid container-xl",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Portfolio"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Check our latest work"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-12 d-flex justify-content-center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            id: "portfolio-flters",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    onClick: ()=>setPortfolios(portfolio),
                                    className: "filter-active",
                                    children: "All"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    onClick: ()=>filterItem("app"),
                                    children: "App"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    onClick: ()=>filterItem("card"),
                                    children: "Card"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    onClick: ()=>filterItem("web"),
                                    children: "Web"
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row gy-4 portfolio-container",
                    children: portfolios.map((portfolio)=>{
                        const { id, title, image, description } = portfolio;
                        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-4 col-md-6 portfolio-item filter-app",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "portfolio-wrap",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: image,
                                        className: "img-fluid",
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "portfolio-info",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: title
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: description
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "portfolio-links",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        "data-gallery": "portfolioGallery",
                                                        className: "portfokio-lightbox",
                                                        title: "App 1",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-plus"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        title: "More Details",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-link"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        }, id);
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const home_Portfolio = (Portfolio);

// EXTERNAL MODULE: ./node_modules/react-slick/lib/index.js
var lib = __webpack_require__(2723);
;// CONCATENATED MODULE: ./app/components/home/SliderTestimonial.js


// slider component is for testimonial slider

class SliderTestimonial extends react_.Component {
    render() {
        // slider configuration
        const settings = {
            dots: true,
            infinite: true,
            speed: 500,
            slidesToShow: 3,
            slidesToScroll: 1
        };
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib/* default */.Z, {
                ...settings,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "testimonial-item",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "stars",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "profile mt-auto",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/testimonials/testimonials-1.jpg",
                                            className: "testimonial-img",
                                            alt: ""
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Saul Goodman"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Ceo & Founder"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "testimonial-item",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "stars",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "profile mt-auto",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/testimonials/testimonials-2.jpg",
                                            className: "testimonial-img",
                                            alt: ""
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Sara Wilsson"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Designer"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "testimonial-item",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "stars",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint minim."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "profile mt-auto",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/testimonials/testimonials-3.jpg",
                                            className: "testimonial-img",
                                            alt: ""
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Jena Karlis"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Store Owner"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "testimonial-item",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "stars",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "profile mt-auto",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/testimonials/testimonials-4.jpg",
                                            className: "testimonial-img",
                                            alt: ""
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "Matt Brandon"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Freelancer"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "testimonial-item",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "stars",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-star-fill"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum quid."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "profile mt-auto",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/testimonials/testimonials-5.jpg",
                                            className: "testimonial-img",
                                            alt: ""
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            children: "John Larson"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                            children: "Entrepreneur"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        });
    }
}

;// CONCATENATED MODULE: ./app/components/home/Testimonials.js


const Testimonials = ()=>{
    return(// testimonials
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "testimonials",
        className: "testimonials",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-xl container-fluid",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Testimonials"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "What they are saying about us"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "testimonials-slider",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SliderTestimonial, {})
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const home_Testimonials = (Testimonials);

;// CONCATENATED MODULE: ./app/components/home/Team.js

const Team = ()=>{
    return(// team section
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "team",
        className: "team",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-xl container-fluid",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Team"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Our hard working team"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row gy-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-3 col-md-6 d-flex align-items-stretch",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "member",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "member-img",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/img/team/team-1.jpg",
                                                className: "img-fluid",
                                                alt: ""
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "social",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-twitter"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-facebook"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-instagram"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-linkedin"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "member-info",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "Walter White"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Chief Executive Officer"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Velit aut quia fugit et et. Dolorum ea voluptate vel tempore tenetur ipsa quae aut. Ipsum exercitationem iure minima enim corporis et voluptate."
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-3 col-md-6 d-flex align-items-stretch",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "member",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "member-img",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/img/team/team-2.jpg",
                                                className: "img-fluid",
                                                alt: ""
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "social",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-twitter"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-facebook"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-instagram"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-linkedin"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "member-info",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "Sarah Jhonson"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Product Manager"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Quo esse repellendus quia id. Est eum et accusantium pariatur fugit nihil minima suscipit corporis. Voluptate sed quas reiciendis animi neque sapiente."
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-3 col-md-6 d-flex align-items-stretch",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "member",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "member-img",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/img/team/team-3.jpg",
                                                className: "img-fluid",
                                                alt: ""
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "social",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-twitter"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-facebook"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-instagram"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-linkedin"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "member-info",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "William Anderson"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "CTO"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Vero omnis enim consequatur. Voluptas consectetur unde qui molestiae deserunt. Voluptates enim aut architecto porro aspernatur molestiae modi."
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-3 col-md-6 d-flex align-items-stretch",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "member",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "member-img",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/img/team/team-4.jpg",
                                                className: "img-fluid",
                                                alt: ""
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "social",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-twitter"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-facebook"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-instagram"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-linkedin"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "member-info",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "Amanda Jepson"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Accountant"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Rerum voluptate non adipisci animi distinctio et deserunt amet voluptas. Quia aut aliquid doloremque ut possimus ipsum officia."
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const home_Team = (Team);

;// CONCATENATED MODULE: ./app/components/home/SliderClient.js
// use client is for client side components
/* __next_internal_client_entry_do_not_use__ default auto */ 

// slider component for react-slick slider

class SliderClient extends react_.Component {
    render() {
        // slider configuration
        const settings = {
            dots: true,
            infinite: true,
            speed: 500,
            slidesToShow: 4,
            slidesToScroll: 1
        };
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(lib/* default */.Z, {
                ...settings,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            width: "75%",
                            src: "/img/clients/client-1.png",
                            className: "img-fluid",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            width: "75%",
                            src: "/img/clients/client-2.png",
                            className: "img-fluid",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            width: "75%",
                            src: "/img/clients/client-3.png",
                            className: "img-fluid",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            width: "75%",
                            src: "/img/clients/client-4.png",
                            className: "img-fluid",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            width: "75%",
                            src: "/img/clients/client-5.png",
                            className: "img-fluid",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            width: "75%",
                            src: "/img/clients/client-6.png",
                            className: "img-fluid",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            width: "75%",
                            src: "/img/clients/client-7.png",
                            className: "img-fluid",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            width: "75%",
                            src: "/img/clients/client-8.png",
                            className: "img-fluid",
                            alt: ""
                        })
                    })
                ]
            })
        });
    }
}

;// CONCATENATED MODULE: ./app/components/home/Clients.js


const Clients = ()=>{
    return(// clients section
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "clients",
        className: "clients",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-xl container-fluid",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Our Clients"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Temporibus omnis officia"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "clients-slider",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " align-items-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SliderClient, {})
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const home_Clients = (Clients);

;// CONCATENATED MODULE: ./app/components/home/Blog.js


const Blog = ()=>{
    return(// blog section
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "recent-blog-posts",
        className: "recent-blog-posts",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-xl container-fluid",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Blog"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Recent posts form our Blog"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-4",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "post-box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "post-img",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/blog/blog-1.jpg",
                                            className: "img-fluid",
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "post-date",
                                        children: "Tue, September 15"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "post-title",
                                        children: "Eum ad dolor et. Autem aut fugiat debitis voluptatem consequuntur sit"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "/blog/1",
                                        className: "readmore stretched-link mt-auto",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Read More"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-arrow-right"
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-4",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "post-box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "post-img",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/blog/blog-2.jpg",
                                            className: "img-fluid",
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "post-date",
                                        children: "Fri, August 28"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "post-title",
                                        children: "Et repellendus molestiae qui est sed omnis voluptates magnam"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "/blog/1",
                                        className: "readmore stretched-link mt-auto",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Read More"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-arrow-right"
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-4",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "post-box",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "post-img",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/img/blog/blog-3.jpg",
                                            className: "img-fluid",
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "post-date",
                                        children: "Mon, July 11"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "post-title",
                                        children: "Quia assumenda est et veritatis aut quae"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "/blog/1",
                                        className: "readmore stretched-link mt-auto",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Read More"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-arrow-right"
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const home_Blog = (Blog);

;// CONCATENATED MODULE: ./app/components/home/Contact.js

const Contact = ()=>{
    return(// contact section
    /*#__PURE__*/ jsx_runtime_.jsx("section", {
        id: "contact",
        className: "contact",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-xl container-fluid",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                    className: "section-header",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Contact"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Contact Us"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row gy-4 mt-4",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "d-flex contact__card_wrapper gap-2 justify-content-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "contact-card d-flex align-items-center justify-content-center gap-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "icon_wrapper",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            class: "bi bi-pass-fill"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "Ticket"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Automate customer service with AI"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "contact-card d-flex align-items-center justify-content-center gap-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "icon_wrapper",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            class: "bi bi-headset"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "HelpDesk"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Support Customers with tickets"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "contact-card d-flex align-items-center justify-content-center gap-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "icon_wrapper",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            class: "bi bi-book-fill"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                children: "KnowledgeBase"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Guide and educate customers"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const home_Contact = (Contact);

;// CONCATENATED MODULE: ./app/components/home/LevelUp.jsx



const LevelUp = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container-fluid container-xl",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "d-flex justify-content-center align-items-center flex-column",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        className: "h2 text-center font-bold mb-4",
                        children: [
                            "Level Up your ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                style: {
                                    color: "#4154F1"
                                },
                                children: "Business"
                            }),
                            " ",
                            "With the Finest Solutions"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "demo-company-wrapper d-flex justify-content-between",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                href: "/schedule-demo",
                                className: "demo text-center font-bold text-white",
                                style: {
                                    width: "400px",
                                    padding: "20px 0px",
                                    fontSize: "22px",
                                    background: "#4154F1",
                                    borderTopLeftRadius: "20px",
                                    borderBottomLeftRadius: "20px"
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "bi bi-headset"
                                    }),
                                    " SCHEDULE A DEMO"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "#",
                                className: "company-profile text-center text-white font-bold",
                                style: {
                                    width: "400px",
                                    padding: "20px 0px",
                                    background: "#012970",
                                    fontSize: "22px",
                                    borderTopRightRadius: "20px",
                                    borderBottomRightRadius: "20px"
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "bi bi-file-earmark-fill"
                                    }),
                                    " COMPANY PROFILE"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "level-up-or-circle",
                                children: "Or"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const home_LevelUp = (LevelUp);

// EXTERNAL MODULE: ./app/db/siteInfo.js
var siteInfo = __webpack_require__(5511);
;// CONCATENATED MODULE: ./app/page.js
/* __next_internal_client_entry_do_not_use__ default auto */ 


















function Home() {
    (0,react_.useEffect)(()=>{
        document.title = siteInfo/* default */.Z.site_name + " - " + siteInfo/* default */.Z.site_title;
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(home_PopUpAd, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(home_Hero, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                id: "main",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(home_About, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Values, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Counts, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Features, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Services, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Pricing, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Portfolio, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Testimonials, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Team, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Clients, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Blog, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Faq, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_Contact, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(home_LevelUp, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 2114:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\2. WEALTH\WD JOB\creative-soft\creative_software\app\page.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,891,723,759], () => (__webpack_exec__(9142)));
module.exports = __webpack_exports__;

})();