"use strict";
(() => {
var exports = {};
exports.id = 548;
exports.ids = [548];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 199:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 9569:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 7542:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'blog',
        {
        children: [
        '[id]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5596)), "D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\blog\\[id]\\page.js"],
          
        }]
      },
        {
        
        
      }
      ]
      },
        {
        
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8326)), "D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\blog\\[id]\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/blog/[id]/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/blog/[id]/page",
        pathname: "/blog/[id]",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 5596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./app/components/blog/BreadCrumbs.js
var BreadCrumbs = __webpack_require__(1500);
// EXTERNAL MODULE: ./app/components/blog/Sidebar.js + 4 modules
var Sidebar = __webpack_require__(640);
;// CONCATENATED MODULE: ./app/components/blog/single/Article.js

const Article = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("article", {
        className: "entry entry-single",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "entry-img",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/img/blog/blog-1.jpg",
                    alt: "",
                    className: "img-fluid"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "entry-title",
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "blog-single.html",
                    children: "Dolorum optio tempore voluptas dignissimos cumque fuga qui quibusdam quia"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "entry-meta",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "d-flex align-items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-person"
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "blog-single.html",
                                    children: "John Doe"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "d-flex align-items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-clock"
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "blog-single.html",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("time", {
                                        datetime: "2020-01-01",
                                        children: "Jan 1, 2020"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "d-flex align-items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-chat-dots"
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "blog-single.html",
                                    children: "12 Comments"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "entry-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Similique neque nam consequuntur ad non maxime aliquam quas. Quibusdam animi praesentium. Aliquam et laboriosam eius aut nostrum quidem aliquid dicta. Et eveniet enim. Qui velit est ea dolorem doloremque deleniti aperiam unde soluta. Est cum et quod quos aut ut et sit sunt. Voluptate porro consequatur assumenda perferendis dolore."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Sit repellat hic cupiditate hic ut nemo. Quis nihil sunt non reiciendis. Sequi in accusamus harum vel aspernatur. Excepturi numquam nihil cumque odio. Et voluptate cupiditate."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("blockquote", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Et vero doloremque tempore voluptatem ratione vel aut. Deleniti sunt animi aut. Aut eos aliquam doloribus minus autem quos."
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Sed quo laboriosam qui architecto. Occaecati repellendus omnis dicta inventore tempore provident voluptas mollitia aliquid. Id repellendus quia. Asperiores nihil magni dicta est suscipit perspiciatis. Voluptate ex rerum assumenda dolores nihil quaerat. Dolor porro tempora et quibusdam voluptas. Beatae aut at ad qui tempore corrupti velit quisquam rerum. Omnis dolorum exercitationem harum qui qui blanditiis neque. Iusto autem itaque. Repudiandae hic quae aspernatur ea neque qui. Architecto voluptatem magni. Vel magnam quod et tempora deleniti error rerum nihil tempora."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Et quae iure vel ut odit alias."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Officiis animi maxime nulla quo et harum eum quis a. Sit hic in qui quos fugit ut rerum atque. Optio provident dolores atque voluptatem rem excepturi molestiae qui. Voluptatem laborum omnis ullam quibusdam perspiciatis nulla nostrum. Voluptatum est libero eum nesciunt aliquid qui. Quia et suscipit non sequi. Maxime sed odit. Beatae nesciunt nesciunt accusamus quia aut ratione aspernatur dolor. Sint harum eveniet dicta exercitationem minima. Exercitationem omnis asperiores natus aperiam dolor consequatur id ex sed. Quibusdam rerum dolores sint consequatur quidem ea. Beatae minima sunt libero soluta sapiente in rem assumenda. Et qui odit voluptatem. Cum quibusdam voluptatem voluptatem accusamus mollitia aut atque aut."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/img/blog/blog-inside-post.jpg",
                        className: "img-fluid",
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Ut repellat blanditiis est dolore sunt dolorum quae."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Rerum ea est assumenda pariatur quasi et quam. Facilis nam porro amet nostrum. In assumenda quia quae a id praesentium. Quos deleniti libero sed occaecati aut porro autem. Consectetur sed excepturi sint non placeat quia repellat incidunt labore. Autem facilis hic dolorum dolores vel. Consectetur quasi id et optio praesentium aut asperiores eaque aut. Explicabo omnis quibusdam esse. Ex libero illum iusto totam et ut aut blanditiis. Veritatis numquam ut illum ut a quam vitae."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Alias quia non aliquid. Eos et ea velit. Voluptatem maxime enim omnis ipsa voluptas incidunt. Nulla sit eaque mollitia nisi asperiores est veniam."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "entry-footer",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "bi bi-folder"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "cats",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                children: "Business"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "bi bi-tags"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "tags",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "#",
                                    children: "Creative"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "#",
                                    children: "Tips"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "#",
                                    children: "Marketing"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const single_Article = (Article);

;// CONCATENATED MODULE: ./app/components/blog/single/Author.js

const Author = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "blog-author d-flex align-items-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                src: "/img/blog/blog-author.jpg",
                className: "rounded-circle float-left",
                alt: ""
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: "Jane Smith"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "social-links",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://twitters.com/#",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-twitter"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://facebook.com/#",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "bi bi-facebook"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://instagram.com/#",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "biu bi-instagram"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Itaque quidem optio quia voluptatibus dolorem dolor. Modi eum sed possimus accusantium. Quas repellat voluptatem officia numquam sint aspernatur voluptas. Esse et accusantium ut unde voluptas."
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const single_Author = (Author);

;// CONCATENATED MODULE: ./app/components/blog/single/CommentItem.js

const CommentItem = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        id: "comment-1",
        className: "comment",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "d-flex",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "comment-img",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/img/blog/comments-1.jpg",
                        alt: ""
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "",
                                    children: "Georgia Reader"
                                }),
                                " ",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "#",
                                    className: "reply",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-reply-fill"
                                        }),
                                        " Reply"
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("time", {
                            dateTime: "2020-01-01",
                            children: "01 Jan, 2020"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Et rerum totam nisi. Molestiae vel quam dolorum vel voluptatem et et. Est ad aut sapiente quis molestiae est qui cum soluta. Vero aut rerum vel. Rerum quos laboriosam placeat ex qui. Sint qui facilis et."
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const single_CommentItem = (CommentItem);

;// CONCATENATED MODULE: ./app/components/blog/single/Comments.js


const Comments = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "blog-comments",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "comments-count",
                children: "8 Comments"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(single_CommentItem, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(single_CommentItem, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(single_CommentItem, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(single_CommentItem, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "reply-form",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: "Leave a Reply"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "Your email address will not be published. Required fields are marked *",
                            " "
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        action: "",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-md-6 form-group",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            name: "name",
                                            type: "text",
                                            className: "form-control",
                                            placeholder: "Your Name*"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-md-6 form-group",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            name: "email",
                                            type: "text",
                                            className: "form-control",
                                            placeholder: "Your Email*"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "row",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col form-group",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        name: "website",
                                        type: "text",
                                        className: "form-control",
                                        placeholder: "Your Website"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "row",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col form-group",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                        name: "comment",
                                        className: "form-control",
                                        placeholder: "Your Comment*"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                type: "submit",
                                className: "btn btn-primary",
                                children: "Post Comment"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const single_Comments = (Comments);

;// CONCATENATED MODULE: ./app/blog/[id]/page.js






const BlogSinglePage = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
            id: "main",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(BreadCrumbs/* default */.Z, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("section", {
                    id: "blog",
                    className: "blog",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "container-fluid container-xl",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-lg-8 entries",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(single_Article, {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx(single_Author, {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx(single_Comments, {})
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-lg-4",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Sidebar/* default */.Z, {})
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const page = (BlogSinglePage);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,891,759,841], () => (__webpack_exec__(7542)));
module.exports = __webpack_exports__;

})();