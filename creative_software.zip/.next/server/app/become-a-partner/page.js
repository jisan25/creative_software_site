(() => {
var exports = {};
exports.id = 235;
exports.ids = [235];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 197:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'become-a-partner',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4187)), "D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\become-a-partner\\page.jsx"],
          
        }]
      },
        {
        
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8326)), "D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["D:\\2. WEALTH\\WD JOB\\creative-soft\\creative_software\\app\\become-a-partner\\page.jsx"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/become-a-partner/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/become-a-partner/page",
        pathname: "/become-a-partner",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 5323:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3235))

/***/ }),

/***/ 3235:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./app/components/be-a-partner/Facilities.jsx

const Facilities = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "h2 mb-4 text-uppercase font-bold mt-2",
                children: "Partner Facilities"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                class: "list-group list-group-flush",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        class: "list-group-item",
                        children: "1. Dream big, work hard, and never give up. Your potential knows no bounds."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        class: "list-group-item",
                        children: "2. Embrace challenges as opportunities, for they are the stepping stones to success."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        class: "list-group-item",
                        children: "3. In every setback, find the lesson. In every triumph, find the gratitude."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        class: "list-group-item",
                        children: "4. Your journey may be tough, but your resilience is tougher. Keep moving forward."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        class: "list-group-item",
                        children: "5. Believe in yourself, for you are the author of your own remarkable story."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        class: "list-group-item",
                        children: "6. Success is not the destination; it's the daily commitment to becoming better.."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        class: "list-group-item",
                        children: "7. The only limit to your achievements is the extent of your determination."
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const be_a_partner_Facilities = (Facilities);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./app/components/be-a-partner/PartnerForm.jsx


const PartnerForm = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-uppercase",
                style: {
                    marginBottom: "5px"
                },
                children: "Become A Partner"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-medium-emphasis",
                style: {
                    marginTop: "0px"
                },
                children: "Please complete the form below to become a partner"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-person-fill"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Name"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-buildings-fill"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Company Name"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-telephone-fill"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "number",
                        placeholder: "Phone Number"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-envelope-fill"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Email"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            class: "bi bi-ubuntu"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Your Designation"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            class: "bi bi-building-fill-gear"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Type of Company"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-caret-down-fill"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                        className: "form-select",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                selected: true,
                                disabled: true,
                                children: "Select Company Size"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "1-10",
                                children: "1-10"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "11-50",
                                children: "11-50"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "51-200",
                                children: "51-200"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "201-500",
                                children: "201-500"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "501-1000",
                                children: "501-1000"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "1000+",
                                children: "1000+"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "employee",
                                children: "Employee"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-caret-down-fill"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                        className: "form-select",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                selected: true,
                                disabled: true,
                                children: "Select Country"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "1",
                                children: "Country 1"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "2",
                                children: "Country 2"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "3",
                                children: "Country 3"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            class: "bi bi-bullseye"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-control",
                        type: "text",
                        placeholder: "Solution Yor're Looking For"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-caret-down-fill"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                        className: "form-select",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                selected: true,
                                disabled: true,
                                children: "How Do You Know Us?"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "google",
                                children: "Google"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "fb",
                                children: "FB"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "linkedin",
                                children: "LinkedIn"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "direct",
                                children: "Direct"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                htmlFor: "add-comments",
                className: "mb-2",
                children: "Additional Comments or Question"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "input-group",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "input-group-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-chat-fill"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                        className: "form-control",
                        placeholder: "optional",
                        id: "add-comments"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "form-check mt-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "form-check-input",
                        type: "checkbox"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        className: "form-check-label",
                        style: {
                            fontSize: "14px"
                        },
                        children: "I agree to receive other communications from creative software"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            "for more information check",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/privacy",
                                style: {
                                    textDecoration: "underline",
                                    color: "#0d6efd"
                                },
                                children: "our privacy policy"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    display: "grid",
                    placeItems: "end"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "btn btn-block btn-success schedule_btn",
                    type: "button",
                    children: "BECOME A PARTNER"
                })
            })
        ]
    });
};
/* harmony default export */ const be_a_partner_PartnerForm = (PartnerForm);

;// CONCATENATED MODULE: ./app/become-a-partner/page.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



// product data from local db
const ProductDetailsPage = ()=>{
    (0,react_.useEffect)(()=>{
        document.title = "Become a Partner - creative software ";
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("main", {
            id: "main",
            children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "become-a-partner",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container-fluid container-xl",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row gy-4 gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-7 schedule_page",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "card mb-4",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "card-body",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(be_a_partner_PartnerForm, {})
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(be_a_partner_Facilities, {})
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const page = (ProductDetailsPage);


/***/ }),

/***/ 4187:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\2. WEALTH\WD JOB\creative-soft\creative_software\app\become-a-partner\page.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,891,759], () => (__webpack_exec__(197)));
module.exports = __webpack_exports__;

})();