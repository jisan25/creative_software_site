exports.id = 759;
exports.ids = [759];
exports.modules = {

/***/ 6872:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7719));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 954, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7490))

/***/ }),

/***/ 2598:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9571, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23))

/***/ }),

/***/ 7490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3500);
// client component is needed for client interctivity
/* __next_internal_client_entry_do_not_use__ default auto */ 
// import react hooks

// arrow up icon from react font awesome

const GoToTop = ()=>{
    // show top button based on state
    const [isVisible, setIsVisible] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    // click to go to top of the page
    const goToBtn = ()=>{
        window.scrollTo({
            top: 0,
            left: 0,
            behavior: "smooth"
        });
    };
    // when user scroll the page
    const listenToScroll = ()=>{
        let heightToHidden = 20;
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
        // show button if scroll
        if (winScroll > heightToHidden) {
            setIsVisible(true);
        } else {
            // hide button if user in on the top of the page
            setIsVisible(false);
        }
    };
    // use effect hook for check the page is scroll & listen to it
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // if scroll the page listen to scroll trigger
        window.addEventListener("scroll", listenToScroll);
        // remove trigger if user is on the top of the page
        return ()=>window.removeEventListener("scroll", listenToScroll);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isVisible && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "go-to-top-section",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "top-btn",
                onClick: goToBtn,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__/* .FaArrowUp */ .ZTc, {
                    className: "top-btn--icon"
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GoToTop);


/***/ }),

/***/ 7719:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_Header)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./app/db/siteInfo.js
var siteInfo = __webpack_require__(5511);
// EXTERNAL MODULE: ./app/db/Corporate.js
var Corporate = __webpack_require__(1762);
;// CONCATENATED MODULE: ./app/components/navbar/products.js




const Products = ()=>{
    const [products, setProducts] = (0,react_.useState)(Corporate/* ProductsData */.G);
    const truncateParagraph = (paragraph, maxLength)=>{
        if (paragraph.length <= maxLength) {
            return paragraph;
        } else {
            return paragraph.slice(0, maxLength) + "...";
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "product__sec",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "d-flex justify-content-around gap-3",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "product__col__wrapper row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: "PRODUCTS "
                    }),
                    products.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-md-3",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "d-flex justify-content-between mb-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: item.icon
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                className: "title-desc",
                                                style: {
                                                    display: "block",
                                                    whiteSpace: "normal"
                                                },
                                                href: "/product/" + item.slug,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                        children: item.title
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mb-2",
                                                        children: truncateParagraph(item.description, 80)
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                className: "mt-4 font-bold product_learn-more",
                                                href: "/product/" + item.slug,
                                                style: {
                                                    display: "inline",
                                                    color: "#4154F1"
                                                },
                                                children: [
                                                    "Learn More ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-arrow-right"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        }, item.id))
                ]
            })
        })
    });
};
/* harmony default export */ const products = (Products);

;// CONCATENATED MODULE: ./app/components/navbar/services.js




const Services = ()=>{
    const [services, setServices] = (0,react_.useState)(Corporate/* default */.Z);
    const truncateParagraph = (paragraph, maxLength)=>{
        if (paragraph.length <= maxLength) {
            return paragraph;
        } else {
            return paragraph.slice(0, maxLength) + "...";
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "product__sec",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "d-flex justify-content-around gap-3",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "product__col__wrapper services__col__wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: "Check our Services"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: services.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-md-4",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "d-flex justify-content-between mb-3",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: item.icon
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                    children: item.title
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: truncateParagraph(item.description, 125)
                                                }),
                                                item.slug === "it-outsourcing" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                    className: "mt-2 font-bold",
                                                    href: "/services/" + item.slug,
                                                    style: {
                                                        display: "inline",
                                                        color: "#4154F1",
                                                        padding: "0px"
                                                    },
                                                    children: [
                                                        "Learn More ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "bi bi-arrow-right"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }, item.id))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const services = (Services);

;// CONCATENATED MODULE: ./app/components/navbar/company.js


const Company = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "company_section",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "d-flex justify-content-around gap-4 align-items-start",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "title",
                        children: "about creative software"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                            className: "font-bold h5",
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    style: {
                                        color: "#4154F1"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        style: {
                                            fontSize: "25px"
                                        },
                                        class: "bi bi-headset"
                                    })
                                }),
                                " ",
                                "+88 9696 66 88 14"
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "company-col-1 col-lg-5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit recusandae eveniet exercitationem maxime laudantium reprehenderit atque, consequatur veritatis, dolorum deserunt, vel voluptas non quibusdam id et quisquam sapiente doloribus. Possimus!"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "company-col-2 col-lg-3 d-flex flex-column align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: "/career",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-laptop"
                                        }),
                                        " Careers"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: "/contact",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-headset"
                                        }),
                                        " Contact Us"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                    href: "/become-a-partner",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            class: "bi bi-person-fill-add"
                                        }),
                                        " Become a Partner"
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "company-col-3 col-lg-4 d-flex flex-column  align-items-center mt-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "navbar-social-links",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-center h4",
                                    children: "Follow Us On"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "d-flex gap-2 justify-content-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "#",
                                            className: "youtube",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-youtube"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "#",
                                            className: "twitter",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-twitter"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "#",
                                            className: "facebook",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-facebook"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "#",
                                            className: "instagram",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-instagram"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "#",
                                            className: "linkedin",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-linkedin"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const company = (Company);

;// CONCATENATED MODULE: ./app/components/navbar/support.js

const Support = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "company_section",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "title",
                children: "need any help ?"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row mb-3",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "company-col-2 col-lg-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "#",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-buildings-fill"
                                        }),
                                        " Community"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "#",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-laptop"
                                        }),
                                        " Knowledge Base"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "#",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-headset"
                                        }),
                                        " Services"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "#",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "bi bi-newspaper"
                                        }),
                                        " Training"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    href: "#",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            class: "bi bi-pass-fill"
                                        }),
                                        " Ticket"
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "company-col-middle col-lg-4",
                        style: {
                            background: "#4154F1",
                            color: "white",
                            padding: "20px 25px"
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mb-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        className: "mb-1",
                                        children: "24/7 support from Createive Software internal experts"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        className: "company-link",
                                        href: "#",
                                        style: {
                                            color: "ghostwhite",
                                            display: "inline",
                                            marginLeft: "0px",
                                            paddingLeft: "0px"
                                        },
                                        children: [
                                            "Let's talk ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-arrow-right"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        children: "Customer resources for suppliers and venues."
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        className: "company-link",
                                        href: "#",
                                        style: {
                                            color: "ghostwhite",
                                            display: "inline",
                                            marginLeft: "0px",
                                            paddingLeft: "0px"
                                        },
                                        children: [
                                            "Learn More ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-arrow-right"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-lg-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row text-center place-content-center place-items-center",
                            style: {
                                height: "100%"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "mb-4",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        style: {
                                            background: "#4154F1",
                                            color: "#fff",
                                            // width: "50px",
                                            borderRadius: "50%",
                                            padding: "25px",
                                            paddingTop: "40px"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            style: {
                                                fontSize: "35px"
                                            },
                                            class: "bi bi-headset"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "mt-1 font-bold h5",
                                    children: "+88 9696 66 88 14"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const support = (Support);

// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\components\\navbar\\resources.js","import":"Roboto","arguments":[{"weight":["300","400","500","700","900"],"subsets":["cyrillic"]}],"variableName":"roboto"}
var target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_ = __webpack_require__(1402);
var target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_default = /*#__PURE__*/__webpack_require__.n(target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_);
;// CONCATENATED MODULE: ./app/components/navbar/resources.js



// const mulish = Mulish({
//     weight: ["300", "400", "500", "600", "700", "800", "900"],
//     subsets: ["latin"],
//     display: "swap",
//   });
const Resources = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "resource__sec",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "row",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "col-lg-4 all-resources",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "mb-3 h4 font-bold",
                            children: "LEARN MORE"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                            className: `${"mb-3"} ${(target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_default()).className}`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bi bi-asterisk"
                                }),
                                " All Resources"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                            className: `${"mb-3"} ${(target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_default()).className}`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bi bi-asterisk"
                                }),
                                " Documentation"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                            className: `${"mb-3"} ${(target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_default()).className}`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bi bi-pen-fill"
                                }),
                                " Blog"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                            className: `${"mb-3"} ${(target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_default()).className}`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bi bi-book-fill"
                                }),
                                " Case Studies"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "col-lg-4 all-resources",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "mb-3 h4 font-bold",
                            children: "LEARN MORE"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                            className: `${"mb-3"} ${(target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_default()).className}`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bi bi-bounding-box"
                                }),
                                " Events"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                            className: `${"mb-3"} ${(target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_default()).className}`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bi bi-hypnotize"
                                }),
                                " Webinars"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                            className: `${"mb-3"} ${(target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_default()).className}`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bi bi-patch-question-fill"
                                }),
                                " FAQS"
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                            className: `${"mb-3"} ${(target_path_app_components_navbar_resources_js_import_Roboto_arguments_weight_300_400_500_700_900_subsets_cyrillic_variableName_roboto_default()).className}`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    class: "bi bi-award-fill"
                                }),
                                " AWARDS AND RECOGNITION"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-lg-4 resource-col-middle d-flex align-items-center justify-content-center text-center",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "mb-1 h6",
                                children: "24/7 support from Createive Software internal experts"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: "company-link",
                                href: "#",
                                style: {
                                    color: "ghostwhite",
                                    display: "inline",
                                    marginLeft: "0px",
                                    paddingLeft: "0px"
                                },
                                children: [
                                    "Let's talk ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "bi bi-arrow-right"
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const resources = (Resources);

;// CONCATENATED MODULE: ./app/components/Header.js
/* __next_internal_client_entry_do_not_use__ default auto */ 


// import siteInfo from "@/app/db/siteInfo";






const Header = ()=>{
    // show nvabar background based on state
    const [isVisible, setIsVisible] = (0,react_.useState)(false);
    // when user scroll the page
    const listenToScroll = ()=>{
        let heightToHidden = 20;
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
        // show button if scroll
        if (winScroll > heightToHidden) {
            setIsVisible(true);
        } else {
            // hide button if user in on the top of the page
            setIsVisible(false);
        }
    };
    // use effect hook for check the page is scroll & listen to it
    (0,react_.useEffect)(()=>{
        // if scroll the page listen to scroll trigger
        window.addEventListener("scroll", listenToScroll);
        // remove trigger if user is on the top of the page
        return ()=>window.removeEventListener("scroll", listenToScroll);
    }, []);
    return(// index header section
    /*#__PURE__*/ jsx_runtime_.jsx("header", {
        id: "header",
        className: `${"header fixed-top"} ${!isVisible && "mt-4 pb-5"} ${isVisible && "header-scrolled"}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container-fluid container-xl d-flex align-items-center justify-content-between",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                    href: "/",
                    className: "logo d-flex align-items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/img/logo.png",
                            alt: ""
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: siteInfo/* default */.Z.site_name
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                    id: "navbar",
                    className: "navbar",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "dropdown company_menu",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            href: "#",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Company"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-chevron-down"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(company, {})
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "dropdown services_menu",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            href: "#",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Services"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-chevron-down"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(services, {})
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "dropdown products_menu",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            href: "/product",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Products"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-chevron-down"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(products, {})
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "dropdown resources_menu",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            href: "#",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Resources"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-chevron-down"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(resources, {})
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "dropdown support_menu",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            href: "#",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Support"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-chevron-down"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(support, {})
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        className: "btn btn-light login_btn icon_style",
                                        href: "/login",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-box-arrow-in-right"
                                            }),
                                            " Login"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        className: "btn btn-primary shedule_btn icon_style",
                                        href: "/schedule-demo",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "bi bi-calendar3"
                                            }),
                                            " Shedule A Demo"
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-list mobile-nav-toggle"
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const components_Header = (Header);


/***/ }),

/***/ 1762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   G: () => (/* binding */ ProductsData),
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const ServicesData = [
    {
        id: 1,
        icon: "bi bi-server",
        title: "Software Development",
        slug: "software-development",
        color: "blue",
        description: "Software development is the art and science of designing, coding, testing, and maintaining computer programs and applications. It involves translating ideas into functional software solutions that cater to specific needs and requirements. This dynamic field fuels technological innovation, underpinning everything from mobile apps to complex business systems, driving progress in our digital world."
    },
    {
        id: 2,
        icon: "bi bi-globe2",
        title: "Website Development",
        slug: "website-development",
        color: "red",
        description: "Website development involves the design, coding, and maintenance of websites to ensure they function seamlessly on the internet. It encompasses a wide range of tasks, from creating the website's structure and layout to implementing interactive features and ensuring compatibility across different devices and browsers. Effective website development is crucial for establishing a strong online presence, engaging visitors, and achieving specific goals, whether they are related to business, information dissemination, or online communities. It combines creativity with technical expertise to deliver user-friendly and visually appealing websites that meet the needs of both site owners and their audiences."
    },
    {
        id: 3,
        icon: "bi bi-android2",
        title: "Apps Development",
        slug: "apps-development",
        color: "pink",
        description: "App development involves the process of designing, coding, and launching software applications for various platforms, such as mobile devices, desktops, and the web. App developers use programming languages and tools to create functional and user-friendly applications that serve specific purposes, from productivity and entertainment to solving practical problems. The rapid evolution of technology has made app development a pivotal force in the digital landscape, enabling businesses and individuals to connect with users, streamline processes, and enhance daily life through intuitive and innovative software solutions."
    },
    {
        id: 4,
        icon: "bi bi-laptop-fill",
        title: "Digital Marketing",
        slug: "digital-marketing",
        color: "orange",
        description: "Digital marketing is a strategic approach to promoting products, services, or brands using digital channels and technologies. It encompasses activities such as search engine optimization (SEO), social media marketing, email marketing, content creation, and online advertising. Digital marketing leverages the power of the internet to reach and engage target audiences, track performance metrics, and optimize campaigns for maximum impact. In today's digital age, it is a vital component of any successful marketing strategy, allowing businesses to connect with customers, drive conversions, and stay competitive in the digital landscape."
    },
    {
        id: 5,
        icon: "bi bi-brush-fill",
        title: "UI / UX Design",
        slug: "ui-ux-design",
        color: "purple",
        description: "UI (User Interface) and UX (User Experience) design are disciplines focused on creating optimal digital interactions. UI design primarily deals with the visual and interactive aspects of a digital product, ensuring it is visually appealing and easy to navigate. UX design, on the other hand, focuses on the overall user journey, aiming to make it seamless, intuitive, and enjoyable. Together, they aim to create user-centric and visually pleasing digital experiences that meet both functional and aesthetic requirements."
    },
    {
        id: 6,
        icon: "bi bi-laptop",
        title: "IT Outsourcing",
        slug: "it-outsourcing",
        color: "green",
        description: "IT outsourcing refers to the practice of delegating certain technology-related tasks, services, or projects to external service providers. This strategic business decision allows organizations to leverage the expertise, resources, and cost-efficiency of external specialists, often located in different geographic regions. IT outsourcing can encompass a wide range of services, such as software development, technical support, infrastructure management, and more. By outsourcing IT functions, companies can focus on their core operations while benefiting from specialized skills and cost savings."
    }
];
const ProductsData = [
    {
        id: 1,
        icon: "bi bi-clipboard-data-fill",
        slug: "point-of-sales-software",
        title: "Point of Sales Software",
        description: "Point of sale (POS) software is a specialized application designed to streamline and manage retail transactions. It enables businesses to efficiently process sales, track inventory, accept payments, generate receipts, and often includes reporting and analytics tools for better business management. POS software helps businesses improve customer service, reduce errors, and gain insights into their sales data, ultimately enhancing overall operational efficiency and profitability.",
        category: [
            {
                id: 1,
                name: "Departmental Store",
                icon: "bi bi-shop"
            },
            {
                id: 2,
                name: "Fashion House",
                icon: "bi bi-palette-fill"
            },
            {
                id: 3,
                name: "Restaurant",
                icon: "bi bi-cup-straw"
            },
            {
                id: 4,
                name: "jewellery Store",
                icon: "bi bi-flower1"
            },
            {
                id: 5,
                name: "Electronic Store",
                icon: "bi bi-cpu"
            },
            {
                id: 6,
                name: "Saloon",
                icon: "bi bi-scissors"
            },
            {
                id: 7,
                name: "Gym & Fitness Center",
                icon: "bi bi-hourglass-split"
            },
            {
                id: 8,
                name: "Parlor",
                icon: "bi bi-yelp"
            },
            {
                id: 9,
                name: "Building Materials",
                icon: "bi bi-buildings-fill"
            },
            {
                id: 10,
                name: "Fruits Shop",
                icon: "bi bi-shop"
            },
            {
                id: 11,
                name: "Sharee And Boutique",
                icon: "bi bi-bag-check-fill"
            },
            {
                id: 12,
                name: "Cosmetic Shop",
                icon: "bi bi-flower2"
            },
            {
                id: 13,
                name: "Pharmacy",
                icon: "bi bi-capsule"
            },
            {
                id: 14,
                name: "Tailor Store",
                icon: "bi bi-columns-gap"
            },
            {
                id: 15,
                name: "Computer Shop",
                icon: "bi bi-laptop-fill"
            },
            {
                id: 16,
                name: "Flour Mill Factory",
                icon: "bi bi-recycle"
            },
            {
                id: 17,
                name: "Shoe Shop",
                icon: "bi bi-shop"
            },
            {
                id: 18,
                name: "Trading Function",
                icon: "bi bi-ubuntu"
            },
            {
                id: 19,
                name: "Arms Shop",
                icon: "bi bi-upc-scan"
            }
        ]
    },
    {
        id: 2,
        icon: "bi bi-ui-checks",
        slug: "restaurant-management-software",
        title: "Restaurant Management Software",
        description: "Restaurant management software is a comprehensive digital solution tailored for the foodservice industry. It facilitates efficient restaurant operations by automating tasks such as order management, reservations, table assignments, menu updates, staff scheduling, and inventory tracking. Additionally, it often includes features for payment processing, customer relationship management (CRM), and analytics to enhance decision-making and customer service. Restaurant management software empowers establishments to improve efficiency, reduce costs, and provide a better dining experience for their patrons."
    },
    {
        id: 3,
        icon: "bi bi-x-diamond",
        slug: "freight-forwarding-software",
        title: "Freight forwarding Software",
        description: "Freight forwarding software is a digital tool tailored for logistics companies and freight forwarders to efficiently manage and optimize the shipment of goods. It streamlines tasks such as cargo tracking, documentation, scheduling, cost calculation, and communication with carriers and clients. This software enhances supply chain visibility, automates processes, and improves overall efficiency in the freight forwarding industry."
    },
    {
        id: 4,
        icon: "bi bi-building-fill-add",
        slug: "hospital-management-software",
        title: "Hospital Management Software",
        description: "Hospital Management Software is a comprehensive digital solution designed for healthcare institutions to streamline and optimize their administrative and clinical processes. It helps manage patient information, appointments, billing, inventory, and electronic health records (EHR). Additionally, it often includes features for staff scheduling, reporting, and analytics, enhancing operational efficiency, patient care, and overall management of healthcare facilities. This software facilitates better coordination among various departments and improves the overall quality of healthcare services provided by hospitals."
    },
    {
        id: 5,
        icon: "bi bi-capsule",
        slug: "pharmacy-management-software",
        title: "Pharmacy Management Software",
        description: "Pharmacy Management Software is a digital solution designed for pharmacies and drugstores to efficiently manage various aspects of their operations. It helps in inventory management, prescription processing, patient records, billing, and compliance with regulations. Additionally, it often includes features for drug interaction checks, medication history, and insurance claim processing, enhancing patient safety and customer service. This software streamlines pharmacy workflows, reduces errors, and improves the overall management of pharmaceutical processes, ultimately leading to better patient care and operational efficiency."
    },
    {
        id: 6,
        icon: "bi bi-car-front-fill",
        slug: "parking-management-software",
        title: "Parking Management Software",
        description: "Parking Management Software is a specialized digital tool used by parking facilities, such as garages and lots, to efficiently manage and control their parking operations. It helps in automating tasks like vehicle entry and exit, payment processing, space allocation, and reporting. Additionally, it often includes features like license plate recognition, reservation systems, and real-time occupancy tracking, enhancing the overall efficiency and user experience in parking facilities. This software allows parking operators to optimize space utilization, improve security, and provide a smoother parking experience for customers."
    },
    {
        id: 7,
        icon: "bi bi-truck",
        slug: "courier-management-software",
        title: "Courier Management Software",
        description: "Courier Management Software is a digital solution designed to streamline and optimize the operations of courier and delivery services. It helps manage orders, track shipments, optimize routes, handle scheduling, and automate billing and reporting. Additionally, it often includes features for real-time tracking, proof of delivery, and customer communication, improving efficiency and transparency in the courier industry. This software enables courier companies to enhance their service quality, reduce costs, and provide a better experience for their clients."
    },
    {
        id: 8,
        icon: "bi bi-file-text-fill",
        slug: "prescription-management-system",
        title: "Prescription Management System",
        description: "A Prescription Management System is specialized software designed for healthcare providers and pharmacies to efficiently manage and process medication prescriptions. It helps healthcare professionals electronically generate, store, and transmit prescriptions, ensuring accuracy and compliance with regulations. Additionally, it often includes features for patient records, drug interactions, and medication history, improving patient safety and care. This system streamlines the prescription workflow, reduces errors, and enhances the overall management of medication-related processes in healthcare settings."
    },
    {
        id: 9,
        icon: "bi bi-coin",
        slug: "micro-credit-management-software",
        title: "Micro Credit Management Software",
        description: "Micro Credit Management Software is a digital solution designed for microfinance institutions and organizations that provide small-scale loans to individuals and small businesses. It helps in automating and managing the entire microcredit lifecycle, including loan origination, disbursement, repayment tracking, and reporting. Additionally, it often includes features for client data management, risk assessment, and portfolio analysis, improving the efficiency and accuracy of microcredit operations. This software enables microfinance institutions to serve their clients more effectively, reduce administrative overhead, and make informed lending decisions."
    },
    {
        id: 10,
        icon: "bi bi-hospital",
        slug: "diagnostic-management-system",
        title: "Diagnostic Management System",
        description: "A Diagnostic Management System is a specialized software tool used in healthcare to streamline and enhance the diagnostic testing process. It helps manage patient information, track test orders, process results, and facilitate communication between healthcare providers and diagnostic laboratories. Additionally, it often includes features for quality control, data analysis, and reporting, improving the accuracy and efficiency of diagnostic procedures. This system plays a crucial role in healthcare settings, ensuring that patients receive timely and accurate diagnostic information for effective medical decision-making."
    },
    {
        id: 11,
        icon: "bi bi-recycle",
        slug: "enterprise-resource-planning-erp",
        title: "Enterprise Resource Planning (ERP)",
        description: "Enterprise Resource Planning (ERP) is an integrated software solution used by businesses to manage and streamline various core processes and functions, including finance, human resources, inventory management, supply chain, manufacturing, and more. ERP software provides a centralized database and a suite of applications that enable data sharing and real-time communication across different departments. Its primary goal is to improve operational efficiency, facilitate data-driven decision-making, and enhance overall business performance by providing a comprehensive view of an organization's processes and resources."
    },
    {
        id: 12,
        icon: "bi bi-people-fill",
        slug: "customer-relationship-management",
        title: "Customer Relationship Management",
        description: "Customer Relationship Management (CRM) refers to a strategy and software system that helps businesses effectively manage and nurture their interactions and relationships with customers. CRM software provides tools for storing and analyzing customer data, tracking communication history, managing sales and marketing efforts, and improving customer service. The goal of CRM is to enhance customer satisfaction, increase sales, and drive long-term customer loyalty by providing a better understanding of customer needs and preferences."
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ServicesData);


/***/ }),

/***/ 5511:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const siteInfo = {
    site_name: "Creative Software",
    site_title: "Top ERP Software Development Company in Bangladesh"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (siteInfo);


/***/ }),

/***/ 8326:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\layout.js","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(4010);
var target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_);
;// CONCATENATED MODULE: ./app/components/TopBar.jsx

const TopBar = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "container-xl container-fluid py-3 h6 font-bold",
        style: {
            height: "110px",
            color: "#4154F1"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("marquee", {
            children: "10% discount on all products for a 30-day promotional period."
        })
    });
};
/* harmony default export */ const components_TopBar = (TopBar);

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./app/components/Header.js

const proxy = (0,module_proxy.createProxy)(String.raw`D:\2. WEALTH\WD JOB\creative-soft\creative_software\app\components\Header.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Header = (__default__);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(5124);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./app/components/home/NewsLetter.js
// glbobal css

const NewsLetter = ()=>{
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsx("div", {
            className: "footer-newsletter",
            children: /*#__PURE__*/ _jsx("div", {
                className: "container-xl container-fluid",
                children: /*#__PURE__*/ _jsx("div", {
                    className: "row justify-content-center",
                    children: /*#__PURE__*/ _jsx("div", {
                        className: "col-lg-6 hero-newsletter",
                        children: /*#__PURE__*/ _jsxs("form", {
                            action: "",
                            method: "post",
                            children: [
                                /*#__PURE__*/ _jsx("input", {
                                    type: "email",
                                    name: "email"
                                }),
                                /*#__PURE__*/ _jsx("input", {
                                    type: "submit",
                                    value: "Subscribe"
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const home_NewsLetter = ((/* unused pure expression or super */ null && (NewsLetter)));

;// CONCATENATED MODULE: ./app/components/Footer.js



const Footer = ()=>{
    return(// footer section
    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        id: "footer",
        className: "footer",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "footer-top",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container-xl container-fluid",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row gy-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-lg-5 col-md-12 footer-info",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: "index.html",
                                        className: "logo d-flex align-items-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/img/logo.png",
                                                alt: ""
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: process.env.SITE_NAME
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Creative software is a software Company that specializes in the development, distribution and maintenance of software applications, programs and services. These companies create software products to address a wide range of needs and industries, from consumer-oriented applications like Develops small, medium and large to complex enterprise software for businesses and organizations."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-lg-2 col-6 footer-links",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        children: "Useful Links"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Home"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "About us"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Services"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Terms of service"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Privacy policy"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-lg-2 col-6 footer-links",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        children: "Our Services"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Web Design"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Web Development"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Product Management"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Marketing"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Graphic Design"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-lg-3 col-md-12 footer-links",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        children: "Support"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Community"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Knowledge Base"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Services"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Training"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "bi bi-chevron-right"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "#",
                                                        children: "Ticket"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container-fluid container-xl",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "copyright",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "d-flex justify-content-between align-items-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    "\xa9 2015-",
                                    new Date().getFullYear(),
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "https://www.creativesoftware.com.bd",
                                            "speechify-initial-font-family": "Roboto, sans-serif",
                                            "speechify-initial-font-size": "16px",
                                            children: "Creative Software.\xa0"
                                        })
                                    }),
                                    "All Rights Reserved."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "social-links d-flex align-items-center justify-content-start gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        style: {
                                            marginTop: "-5px"
                                        },
                                        children: "Follow Us on"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "d-flex gap-3",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                className: "youtube",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-youtube"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                className: "twitter",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-twitter"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                className: "facebook",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-facebook"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                className: "instagram",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-instagram"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                className: "linkedin",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "bi bi-linkedin"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "footer_page",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "#",
                                        "speechify-initial-font-family": "Roboto, sans-serif",
                                        "speechify-initial-font-size": "16px",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-bold",
                                                children: "\xb7"
                                            }),
                                            " Data Policy"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "/privacy",
                                        "speechify-initial-font-family": "Roboto, sans-serif",
                                        "speechify-initial-font-size": "16px",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-bold",
                                                children: "\xb7"
                                            }),
                                            " Privacy Policy"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "/terms",
                                        "speechify-initial-font-family": "Roboto, sans-serif",
                                        "speechify-initial-font-size": "16px",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-bold",
                                                children: "\xb7"
                                            }),
                                            " Terms Of Use"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "/return",
                                        "speechify-initial-font-family": "Roboto, sans-serif",
                                        "speechify-initial-font-size": "16px",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-bold",
                                                children: "\xb7"
                                            }),
                                            " Return and Refund Policy"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "/sitemap",
                                        "speechify-initial-font-family": "Roboto, sans-serif",
                                        "speechify-initial-font-size": "16px",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-bold",
                                                children: "\xb7"
                                            }),
                                            " Sitemap"
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const components_Footer = (Footer);

;// CONCATENATED MODULE: ./app/components/GoToTop.jsx

const GoToTop_proxy = (0,module_proxy.createProxy)(String.raw`D:\2. WEALTH\WD JOB\creative-soft\creative_software\app\components\GoToTop.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: GoToTop_esModule, $$typeof: GoToTop_$$typeof } = GoToTop_proxy;
const GoToTop_default_ = GoToTop_proxy.default;


/* harmony default export */ const GoToTop = (GoToTop_default_);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(7272);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__(7047);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick-theme.css
var slick_theme = __webpack_require__(6057);
;// CONCATENATED MODULE: ./app/components/WaChat.jsx


const WaChat = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "wa-chat-wrapper",
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: "#",
            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                className: "wa-chat",
                src: "/img/chat-wa.png",
                alt: "what's app chat"
            })
        })
    });
};
/* harmony default export */ const components_WaChat = (WaChat);

;// CONCATENATED MODULE: ./app/layout.js
// common components






// glbobal css

// react slick carousel css



const metadata = {
    title: process.env.SITE_NAME + " - " + process.env.SITE_TITLE,
    description: process.env.SITE_TITLE
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
            className: (target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default()).className,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(components_TopBar, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
                children,
                /*#__PURE__*/ jsx_runtime_.jsx(GoToTop, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(components_WaChat, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
            ]
        })
    });
}


/***/ }),

/***/ 7481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"16x16"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 7272:
/***/ (() => {



/***/ })

};
;