exports.id = 841;
exports.ids = [841];
exports.modules = {

/***/ 7207:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 954, 23))

/***/ }),

/***/ 1500:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5124);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


const BreadCrumbs = ()=>{
    return(// breadcrumbs
    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "breadcrumbs",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container-xl container-fluid",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ol", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/",
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: "Blog"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    children: "Blog"
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BreadCrumbs);


/***/ }),

/***/ 640:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ blog_Sidebar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
;// CONCATENATED MODULE: ./app/components/blog/sidebar/Categories.js

const Categories = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "sidebar-item categories",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        href: "#",
                        children: [
                            "General ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "(25)"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        href: "#",
                        children: [
                            "Lifestyle ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "(12)"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        href: "#",
                        children: [
                            "Travel ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "(5)"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        href: "#",
                        children: [
                            "Design ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "(22)"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        href: "#",
                        children: [
                            "Creative ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "(8)"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        href: "#",
                        children: [
                            "Educaion ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "(14)"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const sidebar_Categories = (Categories);

;// CONCATENATED MODULE: ./app/components/blog/sidebar/RecentPosts.js

const RecentPosts = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "sidebar-item recent-posts",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "post-item clearfix",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/img/blog/blog-recent-1.jpg",
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "blog-single.html",
                            children: "Nihil blanditiis at in nihil autem"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("time", {
                        datetime: "2020-01-01",
                        children: "Jan 1, 2020"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "post-item clearfix",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/img/blog/blog-recent-2.jpg",
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "blog-single.html",
                            children: "Quidem autem et impedit"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("time", {
                        datetime: "2020-01-01",
                        children: "Jan 1, 2020"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "post-item clearfix",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/img/blog/blog-recent-3.jpg",
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "blog-single.html",
                            children: "Id quia et et ut maxime similique occaecati ut"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("time", {
                        datetime: "2020-01-01",
                        children: "Jan 1, 2020"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "post-item clearfix",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/img/blog/blog-recent-4.jpg",
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "blog-single.html",
                            children: "Laborum corporis quo dara net para"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("time", {
                        datetime: "2020-01-01",
                        children: "Jan 1, 2020"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "post-item clearfix",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/img/blog/blog-recent-5.jpg",
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "blog-single.html",
                            children: "Et dolores corrupti quae illo quod dolor"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("time", {
                        datetime: "2020-01-01",
                        children: "Jan 1, 2020"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const sidebar_RecentPosts = (RecentPosts);

;// CONCATENATED MODULE: ./app/components/blog/sidebar/Search.js

const Search = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "sidebar-item search-form",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            action: "",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    type: "text"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    type: "submit",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "bi bi-search"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const sidebar_Search = (Search);

;// CONCATENATED MODULE: ./app/components/blog/sidebar/Tags.js

const Tags = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "sidebar-item tags",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "App"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "IT"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "Business"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "Mac"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "Design"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "Office"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "Creative"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "Studio"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "Smart"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "Tips"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: "Marketing"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const sidebar_Tags = (Tags);

;// CONCATENATED MODULE: ./app/components/blog/Sidebar.js





const Sidebar = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "sidebar",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "sidebar-title",
                children: "Search"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(sidebar_Search, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "sidebar-title",
                children: "Categories"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(sidebar_Categories, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "sidebar-title",
                children: "Recent Posts"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(sidebar_RecentPosts, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "sidebar-title",
                children: "Tags"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(sidebar_Tags, {})
        ]
    });
};
/* harmony default export */ const blog_Sidebar = (Sidebar);


/***/ })

};
;