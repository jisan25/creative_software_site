const ReturnPage = () => {
  return (
    <main id="main" style={{ marginTop: "50px" }}>
      <section className="inner-page">
        <div className="container-xl container-fluid">
          <p className="font-bold" style={{ fontSize: "20px" }}>
            Return Page
          </p>
        </div>
      </section>
    </main>
  );
};

export default ReturnPage;
