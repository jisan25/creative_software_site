const AboutCompany = () => {
  return (
    <div
      className="container-xl container-fluid py-5"
      style={{ background: "#4154F1" }}
    >
      <h2 className="text-center mb-3 font-bold h1 text-white text-uppercase">
        Join Our Team
      </h2>
      <p className="text-center" style={{ color: "#e2e6ea" }}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis
        debitis vel saepe possimus esse labore eaque, facilis fugiat consectetur
        nam nostrum aperiam necessitatibus molestiae, odio explicabo unde id
        temporibus neque!
      </p>
    </div>
  );
};

export default AboutCompany;
