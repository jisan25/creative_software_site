const TopBar = () => {
  return (
    <div
      className="container-xl container-fluid py-3 h6 font-bold"
      style={{ height: "110px", color: "#4154F1" }}
    >
      <marquee>
        10% discount on all products for a 30-day promotional period.
      </marquee>
    </div>
  );
};

export default TopBar;
