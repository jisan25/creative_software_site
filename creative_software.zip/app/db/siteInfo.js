const siteInfo = {
  site_name: "Creative Software",
  site_title: "Top ERP Software Development Company in Bangladesh",
};

export default siteInfo;
