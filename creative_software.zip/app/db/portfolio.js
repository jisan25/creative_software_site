const PortfolioData = [
  {
    id: 1,
    image: "/img/portfolio/portfolio-1.jpg",
    title: "App 1",
    category: "app",
    description: "App",
  },
  {
    id: 2,
    image: "/img/portfolio/portfolio-2.jpg",
    title: "Web 1",
    category: "web",
    description: "Web",
  },
  {
    id: 3,
    image: "/img/portfolio/portfolio-3.jpg",
    title: "card 1",
    category: "card",
    description: "card",
  },
  {
    id: 4,
    image: "/img/portfolio/portfolio-4.jpg",
    title: "Card 2",
    category: "card",
    description: "Card",
  },
  {
    id: 5,
    image: "/img/portfolio/portfolio-5.jpg",
    title: "App 2",
    category: "app",
    description: "App",
  },
  {
    id: 6,
    image: "/img/portfolio/portfolio-6.jpg",
    title: "Web 2",
    category: "web",
    description: "Web",
  },
  {
    id: 7,
    image: "/img/portfolio/portfolio-7.jpg",
    title: "App 3",
    category: "app",
    description: "App",
  },
  {
    id: 8,
    image: "/img/portfolio/portfolio-8.jpg",
    title: "Card 3",
    category: "card",
    description: "Card",
  },
  {
    id: 9,
    image: "/img/portfolio/portfolio-9.jpg",
    title: "Web 3",
    category: "web",
    description: "Web",
  },
];

export default PortfolioData;
