const ServicePage = () => {
  return <div>Service Page</div>;
};

export default ServicePage;
