const TermsPage = () => {
  return (
    <main id="main" style={{ marginTop: "50px" }}>
      <section className="inner-page">
        <div className="container-xl container-fluid">
          <p className="font-bold" style={{ fontSize: "20px" }}>
            Terms Page
          </p>
        </div>
      </section>
    </main>
  );
};

export default TermsPage;
